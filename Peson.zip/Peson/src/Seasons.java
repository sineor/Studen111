import javax.swing.*;

import java.util.Scanner;

public class Seasons {
    public void findSeason(int monthNumber) {
        if (monthNumber >= 1 && monthNumber <= 12) {
            String season;
            if (monthNumber >= 3 && monthNumber <= 5) {
                season = "jaz";
            } else if (monthNumber >= 6 && monthNumber <= 8) {
                season = "jai";
            } else if (monthNumber >= 9 && monthNumber <= 11) {
                season = "kuz";
            } else {
                season = "kysh";
            }
            System.out.println("ai " + monthNumber + " ushul mezgilge tiecheluu " + season + ".");
        } else {
            System.out.println("Введенное значение не является порядковым номером месяца.");
        }
    }
// Scanner scanner = new Scanner(System.in);
//        System.out.print("Введите порядковый номер месяца: ");
//        int monthNumber = scanner.nextInt();
//
//        Seasons seasons = new Seasons();
//        seasons.findSeason(monthNumber);
//    }


}
