public class Rectangle {
    private int lenth;
    private int with;

    public void setLenth(int lenth) {

        this.lenth = lenth;
    }

    public void setwith(int width) {

        this.with = width;
    }


    public int Ss() {
        int Ss = lenth * with;
        return Ss;

    }
    }

