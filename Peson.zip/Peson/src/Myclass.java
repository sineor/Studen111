public class Myclass {
    String name;
    String surname;
    int age;
    String[] sabak;
    String food;

    public Myclass(String name, String surname, int age, String[] sabak, String food) {
        this.name = name;
        this.surname = surname;
        this.age = age;
        this.sabak = sabak;
        this.food = food;
    }
    public Myclass(){
        this.name = name;
        this.surname = surname;
        this.age = age;
        this.sabak = sabak;
        this.food = food;

}
}