public class Person {

    String firstname;
    String lastname;
    int dateofbirth;




        }

