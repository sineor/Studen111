import java.time.LocalDate;
import java.util.Arrays;
import java.util.Scanner;
public class Main  {

    public static void main(String[] args) {

      /*  MyClass деген класс тузунуз

        Ал класста озунуз жонундо маалымат сактаган полелер болсун(атыныз, фамилияныз, жашыныз,
        Peaksoft то катышкан сабактарыныз(массив), жакшы коргон тамагыныз)

        Параметри эки башка болгон эки конструктор тузунуз

        MyClassтын 2 объектисин тузуп, конструктор аркылуу маани бериниз

        Эки объектке эки башка конструктор иштесин.

        Объекттердин маанилерин консольго чыгарыныз.*/
     /*   Myclass mycl = new Myclass();
        String[] sabak = {OOP,Array,constructor};
        mycl.name = "Nurles";
        mycl.surname = "Subanbaev";
        mycl.age = 20;
        mycl.food = "lagman";



        Myclass mycls = new Myclass();
        String[] sabak = {OOP,Array,constructor};
        mycls.name = "Erkin";
        mycls.surname = "Toigonbaev";
        mycls.age = 21;
        mycls.food = "Shorpo";*/
      /* Rectangle rect = new Rectangle();
        rect.setwith(7);
        rect.setwith(7);
        System.out.println(rect.Ss());*/

       /* Task task = new Task();
        task.company  = "Shoro";
        task.country = "Kyrgyzstan";
        task.founder = "T.Egemberdiev";
         String[] groups = {"Chalap","maksym","Kvas"};
        task.year = 2009;*/














         //   System.out.println("Возраст студента: " + student.getAge() + " лет");//            System.out.println();*/
      /* Book book0 = new Book("betme bet",40,"Chyngyz Aitmatov");
        Book book1 = new Book("Syngan Kylych",77,"T. Kasynbekov");
        Book book02 = new Book("Ant",29,"N. kadyrbekov");
        Book book03 = new Book("Bir man",55,"Deputat");
        Book book04 = new Book("Kel kel",67,"T. kasymbekov");

        Book [] books = {book0,book1,book02,book03,book04};
        Library library = new Library("Ysyk-Kol", "123 Main Street", books);


        System.out.println(Arrays.toString(library.getBooks()));*/

       // Student s = new Student();
        //s.name = "Danielle";
        //String name = s.toString();
      /* Flower flow = new Flower("Aigul",6,999);
        Flower flow1 = new Flower("Joogazyn",4,454);
        Flower flow2 = new Flower("Roza",4,476);
        Flower flow3 = new Flower("Baichechekei",7,800);

        Flower[] flowers = {flow,flow1,flow2,flow3,};*/
        Student students1 = new Student("N. Subanbaev", LocalDate.of(2002,2,9),558270902,"KG");
        Student students2 = new Student("S.lavrov", LocalDate.of(1992,1,5),899867845,"RU");
        Student students3 = new Student("Jon Bython", LocalDate.of(2000,8,2),8376498,"USA");
        Student students4 = new Student("B.Ahmadjon", LocalDate.of(2001,11,3),9846589,"UZB");
        Student students5 = new Student("C.AKYL", LocalDate.of(1985,11,10),83979689,"KZ");


        Student[] students = {students1,students2,students3,students4,students5};
        for (Student student : students) {
            System.out.println(student);  //            System.out.println(student);

            //  Scanner scanner = new Scanner(System.in);
//        System.out.print("Введите порядковый номер месяца: ");
//        int monthNumber = scanner.nextInt();
//
//        Seasons seasons = new Seasons();
//        seasons.findSeason(monthNumber);














        }
    }}






















