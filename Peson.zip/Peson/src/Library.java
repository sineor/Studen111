import java.util.Arrays;

public class Library {
    private String name;
    private String address;
    private Book[] books;
    public Library(String name, String address, Book[] books) {
        this.name = name;
        this.address = address;
        this.books = books;
    }
    public String getName() {

        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getAddress() {

        return address;
    }
    public void setAddress(String address) {

        this.address = address;
    }
    public Book[] getBooks() {

        return books;
    }
    public void setBooks(Book[] books) {

        this.books = books;
    }
    public String addABookToTheLibrary(Book book){
        for (Book b:books) {
            if(b.getName().equals(book.getName())){
                return "Myndai kitep bizde bar ";
            }

        }
        Book[] books1 = new Book[books.length+1];
        for (int i = 0; i < books.length; i++) {
            books1[i] = books[i];

        }
     books1[books.length]= book;
        books = Arrays.copyOf(books1,books.length);

        return "Siz jany kitep koshtiunuz";
    }
    public Book[] removeBookFromLibrary(String bookName){

        return books;
    }
    public Book updateBookByName(String bookName, int newQuantity){
        Book book = new Book();
        return book;
    }
    public Book [] getAllBookByAuthor(String author){
        return books;
    }
    @Override
    public String toString() {
        return "Library{" +
                "name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", books=" + Arrays.toString(books) +
                '}';
    }
}

