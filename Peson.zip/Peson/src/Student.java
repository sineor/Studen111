import java.time.LocalDate;

public class Student {
    String name;
    LocalDate data;
    int phoneNumber;
    String nationality;
public Student(){

}

    public Student(String name, LocalDate data, int phoneNumber, String nationality) {
        this.name = name;
        this.data = data;
        this.phoneNumber = phoneNumber;
        this.nationality = nationality;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", data=" + data +
                ", phoneNumber=" + phoneNumber +
                ", nationality='" + nationality + '\'' +
                '}';

    }
}
